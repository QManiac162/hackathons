# Solar System Model app

Solar System Model app

## Platforms

Fully rendered in browser, no server-side components required

## Todo

- Add date/time selector
- Add Milky way background
- Add Data printouts
- Correct starting Earth rotation

## Investigate

- Asterank  
  <http://www.asterank.com/>  
  <https://github.com/typpo/asterank>  
